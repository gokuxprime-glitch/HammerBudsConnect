# HAMMER Buds Connect — Android starter project

This is a Kotlin Android Studio starter project with:
- permission request flow for Bluetooth (Android 12+), notification (Android 13+), and overlay permission (special Settings screen)
- foreground service that listens for Bluetooth ACL connect/disconnect broadcasts
- HTML/CSS popup hosted in Android WebView
- demo popup preview

## Open and build
1. Install Android Studio on a computer.
2. Open this `HammerBudsConnect` folder in Android Studio.
3. Let Gradle sync. Use JDK 17 and Android SDK 35.
4. Connect an Android phone, enable USB debugging, and press Run.
5. In the app, grant Bluetooth/notification permissions, allow "Display over other apps", then start monitoring.

## Important limitations
- This is starter source code, not a tested/compiled APK. A build requires Android Studio/Gradle and SDK installation.
- Bluetooth ACL broadcasts indicate a Bluetooth link, not guaranteed earbuds-only connections. The service filters by device name/class as a basic heuristic.
- Android does not provide universal left/right/case battery values. Some headsets expose a standard battery characteristic or Android battery extra; many HAMMER models do not. This starter intentionally shows unavailable rather than made-up values.
- Background execution, popup launch, and overlay behavior vary by Android version and phone manufacturer. Android may restrict background activity launches. A production release should use a high-priority notification with a user-tappable popup as fallback and test on the target phone.
- For accurate battery integration, add model-specific GATT/protocol support after identifying the exact HAMMER model and inspecting what it exposes.
- Gallery image/video theme persistence and a full theme editor are the next implementation step; the popup currently provides the native shell and a bundled HTML UI.

## Permissions are user-controlled
The app requests runtime permissions and opens Android Settings for overlay access. It cannot grant these permissions itself.
