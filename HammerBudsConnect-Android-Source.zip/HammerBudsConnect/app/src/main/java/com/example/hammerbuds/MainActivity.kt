package com.example.hammerbuds

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(0xFF080B13.toInt())
        }
        val title = TextView(this).apply {
            text = "HAMMER Buds Connect\n\nAutomatic connection popup + battery when supported"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val permissions = Button(this).apply {
            text = "1. Grant Bluetooth / notification permissions"
            setOnClickListener { requestRuntimePermissions() }
        }
        val overlay = Button(this).apply {
            text = "2. Allow popup over other apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Popup permission already allowed", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "3. Start connection monitoring"
            setOnClickListener {
                val i = Intent(this@MainActivity, ConnectionService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this@MainActivity, "Monitoring started. Keep app enabled in battery settings.", Toast.LENGTH_LONG).show()
            }
        }
        val test = Button(this).apply {
            text = "Preview popup"
            setOnClickListener { startActivity(Intent(this@MainActivity, PopupActivity::class.java)) }
        }
        val note = TextView(this).apply {
            text = "\nBattery note: many HAMMER models do not publish separate left/right/case levels to Android. The app displays real battery only when the earbuds expose it; otherwise it shows unavailable rather than inventing values."
            textSize = 14f
            setTextColor(0xFFB8C4D8.toInt())
        }
        listOf(title, permissions, overlay, start, test, note).forEach { layout.addView(it) }
        setContentView(layout)
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
            needed += Manifest.permission.BLUETOOTH_SCAN
        } else {
            needed += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(needed.toTypedArray(), requestCode)
    }
}
