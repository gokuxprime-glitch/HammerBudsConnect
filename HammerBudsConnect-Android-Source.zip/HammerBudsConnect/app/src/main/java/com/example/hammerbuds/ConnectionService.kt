package com.example.hammerbuds

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ConnectionService : Service() {
    private val channelId = "hammer_buds_monitor"

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
            val name = try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) "Bluetooth earbuds"
                else device?.name ?: "Bluetooth earbuds"
            } catch (_: Exception) { "Bluetooth earbuds" }

            when (intent.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    // Only launch for a likely headset; Android's ACL event can include other devices too.
                    val cls = try { device?.bluetoothClass?.majorDeviceClass } catch (_: Exception) { -1 }
                    if (cls == 1024 || name.contains("hammer", true) || name.contains("ear", true) || name.contains("buds", true)) {
                        val popup = Intent(this@ConnectionService, PopupActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            putExtra("device_name", name)
                            putExtra("connected", true)
                        }
                        startActivity(popup)
                    }
                }
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    // Intentionally do not force-open a full-screen popup on disconnect.
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("HAMMER Buds Connect is active")
            .setContentText("Listening for Bluetooth earbud connections")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        startForeground(10, notification)

        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(bluetoothReceiver, filter, RECEIVER_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(bluetoothReceiver, filter)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Earbud connection monitoring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(bluetoothReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
